<!-- Call To Action End -->
<div class="section-full call-action bg-primary wow xfadeIn" data-wow-duration="2s" data-wow-delay="0.2s">
    <div class="container">
        <div class="row">
            <div class="col-lg-9 text-white">
                <h2 class="title">Amazing things happen to your business </h2>
                <p class="m-b0">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
            </div>
            <div class="col-lg-3 d-flex">
                <a href="about-2.html"
                   class="site-button white align-self-center outline ml-auto radius-xl outline-2 btnhover16 btnhover16">MARKET
                    SECTORS </a>
            </div>
        </div>
    </div>
</div>
<!-- Call To Action End -->
